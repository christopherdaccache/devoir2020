package Comptes;

public class Fournisseur extends Compte {
}

package Comptes;

public abstract class Compte {
}

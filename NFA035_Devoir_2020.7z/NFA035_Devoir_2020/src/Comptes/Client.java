package Comptes;

public class Client extends Compte {
}

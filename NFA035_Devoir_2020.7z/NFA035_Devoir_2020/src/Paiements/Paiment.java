package Paiements;
import Transactions.*;

public class Paiment extends TransactionFournisseur {
}

package Transactions;

import java.io.Serializable;
import java.util.Date;

enum ModePaie{
    CASH, CHEQUE, TRANSFERT;
}

public abstract class Transaction implements Comparable, Serializable {
    private ModePaie modePaie;
    private static int noSerie;
    private int noTransaction;
    private String description;
    private Date dateTransaction;
    private double montant;

    public static int getNoSerie() {
        return noSerie;
    }

    public static void setNoSerie(int noSerie) {
        Transaction.noSerie = noSerie;
    }

    public ModePaie getModePaie() {
        return modePaie;
    }

    public void setModePaie(ModePaie modePaie) {
        this.modePaie = modePaie;
    }

    public int getNoTransaction() {
        return noTransaction;
    }

    public void setNoTransaction(int noTransaction) {
        this.noTransaction = noTransaction;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getDateTransaction() {
        return dateTransaction;
    }

    public void setDateTransaction(Date dateTransaction) {
        this.dateTransaction = dateTransaction;
    }

    public double getMontant() {
        return montant;
    }

    public void setMontant(double montant) {
        this.montant = montant;
    }

    public Transaction(int noTransaction, String description, Date dateTransaction, double montant, ModePaie modePaie){
        Transaction.noSerie += 1;
        this.noSerie = Transaction.noSerie;
        this.setNoTransaction(noTransaction);
        this.setDescription(description);
        this.setDateTransaction(dateTransaction);
        this.setMontant(montant);
        this.setModePaie(modePaie);
    }

    public String toString(){
        return "numero Transaction: " + this.getNoTransaction() + "\n" +
                "description: " + this.getDescription() + "\n" +
                "date: " + this.getDateTransaction() + "\n" +
                "montant: " + this.getMontant() + "\n" +
                "mode de payment: " + this.getModePaie();
    }

    public int compareTo(Transaction tr){
        if(this.getDescription().compareTo(tr.getDescription()) == 0 &&
                this.getDateTransaction().compareTo(tr.getDateTransaction()) == 0 &&
                this.getNoTransaction() == tr.getNoTransaction())
            return 0;
        else
            if(this.getDescription().compareTo(tr.getDescription()) > 0 ||
                    this.getDateTransaction().compareTo(tr.getDateTransaction()) > 0 ||
                    this.getNoTransaction() > tr.getNoTransaction()) return 1;
        else
            return -1;
    }
}

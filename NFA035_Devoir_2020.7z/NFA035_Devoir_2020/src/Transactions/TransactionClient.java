package Transactions;

public abstract class TransactionClient {
}

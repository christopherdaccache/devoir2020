package Transactions;
import Transactions.*;

public abstract class TransactionFournisseur {
}

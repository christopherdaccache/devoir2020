package Recus;
import Transactions.*;

public class Recu extends TransactionClient {
}

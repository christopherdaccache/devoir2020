package Articles;

public class Article {
}

package Menu;

import Menu.Lib.IGenButtons;
import Menu.Lib.IGenPanel;

import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import javax.swing.*;

public class Menu_Bar
{
    JFrame MainMenu;
    JMenuBar MenuBar;
    JMenu Transactions, Ventes, Achats, Recus, Paiements, Comptes, Fournisseurs, Clients, Stock, Articles, Outils, Quitter;
    JMenuItem QuitterItem, Creer_Ventes, Rapport_Ventes, Creer_Achats, Rapport_Achats, Creer_Recus, Rapport_Recus, Creer_Paiements,
            Rapport_Paiements, Creer_Clients, Rapport_Clients, Creer_Fournisseurs, Rapport_Fournisseurs, Ville, Creer_Articles,
            Rapport_Articles, CategoriesArticles, ChargerDuDisque, SauvegarderSurDisque, Version;

    JPanel ContentPanel;
    Font BorderContentPanelTitleFont;
    Border borderContentPanel;

    public Menu_Bar()
    {
        Initialise();
        this.MainMenu.getContentPane();
        this.MainMenu.repaint();
        this.MainMenu.revalidate();
    }

    private void Initialise()
    {
        try {
            this.MainMenu = new JFrame("Gestion de transactions commercials");
            this.MainMenu.setVisible(true);
            this.MainMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            this.MainMenu.setBounds(100, 100, 750, 650);
            this.MainMenu.setResizable(false);
            this.MainMenu.setLayout(new BorderLayout());

            this.ContentPanel = new JPanel();
            this.ContentPanel.setLayout(new BorderLayout());
            this.ContentPanel.setPreferredSize(new Dimension(656, 585));
            this.MainMenu.add(this.ContentPanel, BorderLayout.CENTER);
            this.changePanel(null);

            this.BorderContentPanelTitleFont = new Font("Tahoma", Font.BOLD, 12);

            JPanel pEmptyWestPanel = new JPanel();
            pEmptyWestPanel.setPreferredSize(new Dimension(15, 10));
            this.MainMenu.add(pEmptyWestPanel, BorderLayout.WEST);

            JPanel pEmptyNorthPanel = new JPanel();
            pEmptyNorthPanel.setPreferredSize(new Dimension(15, 10));
            this.MainMenu.add(pEmptyNorthPanel, BorderLayout.NORTH);

            JPanel pEmptyEastPanel = new JPanel();
            pEmptyEastPanel.setPreferredSize(new Dimension(60, 10));
            this.MainMenu.add(pEmptyEastPanel, BorderLayout.EAST);

            JPanel pEmptySouthPanel = new JPanel();
            pEmptySouthPanel.setPreferredSize(new Dimension(15, 5));
            this.MainMenu.add(pEmptySouthPanel, BorderLayout.SOUTH);

            MenuBar = new JMenuBar();
            this.MainMenu.setJMenuBar(MenuBar);
            
            //Transactions
            Transactions = new JMenu("Transactions");
            Transactions.setMnemonic(KeyEvent.VK_T);
            MenuBar.add(Transactions);

            //Transactions>Ventes_Cntlr
            Ventes = new JMenu("Ventes");
            Ventes.setMnemonic(KeyEvent.VK_V);
            Transactions.add(Ventes);

            Creer_Ventes = new JMenuItem("Creer/Modifier");
            Creer_Ventes.setMnemonic(KeyEvent.VK_C);
            Ventes.add(Creer_Ventes);
            Creer_Ventes.addActionListener(this::actionPerformed);

            Rapport_Ventes = new JMenuItem("Rapport");
            Rapport_Ventes.setMnemonic(KeyEvent.VK_R);
            Ventes.add(Rapport_Ventes);
            Rapport_Ventes.addActionListener(this::actionPerformed);

            //Transactions>Achats
            Achats = new JMenu("Achats");
            Achats.setMnemonic(KeyEvent.VK_A);
            Transactions.add(Achats);

            Creer_Achats = new JMenuItem("Creer/Modifier");
            Creer_Achats.setMnemonic(KeyEvent.VK_C);
            Achats.add(Creer_Achats);
            Creer_Achats.addActionListener(this::actionPerformed);

            Rapport_Achats = new JMenuItem("Rapport");
            Rapport_Achats.setMnemonic(KeyEvent.VK_R);
            Achats.add(Rapport_Achats);
            Rapport_Achats.addActionListener(this::actionPerformed);

            //Transactions>Recus
            Recus = new JMenu("Recus");
            Recus.setMnemonic(KeyEvent.VK_R);
            Transactions.add(Recus);

            Creer_Recus = new JMenuItem("Creer/Modifier");
            Creer_Recus.setMnemonic(KeyEvent.VK_C);
            Recus.add(Creer_Recus);
            Creer_Recus.addActionListener(this::actionPerformed);

            Rapport_Recus = new JMenuItem("Rapport");
            Rapport_Recus.setMnemonic(KeyEvent.VK_R);
            Recus.add(Rapport_Recus);
            Rapport_Recus.addActionListener(this::actionPerformed);

            //Transactions>Paiements
            Paiements = new JMenu("Paiements");
            Paiements.setMnemonic(KeyEvent.VK_P);
            Transactions.add(Paiements);

            Creer_Paiements = new JMenuItem("Creer/Modifier");
            Creer_Paiements.setMnemonic(KeyEvent.VK_C);
            Paiements.add(Creer_Paiements);
            Creer_Paiements.addActionListener(this::actionPerformed);

            Rapport_Paiements = new JMenuItem("Rapport");
            Rapport_Paiements.setMnemonic(KeyEvent.VK_R);
            Paiements.add(Rapport_Paiements);
            Rapport_Paiements.addActionListener(this::actionPerformed);

            //Comptes
            Comptes = new JMenu("Comptes");
            Comptes.setMnemonic(KeyEvent.VK_C);
            MenuBar.add(Comptes);

            //Comptes>Clients
            Clients = new JMenu("Clients");
            Clients.setMnemonic('C');
            Comptes.add(Clients);

            Creer_Clients = new JMenuItem("Creer/Modifier");
            Creer_Clients.setMnemonic(KeyEvent.VK_C);
            Clients.add(Creer_Clients);
            Creer_Clients.addActionListener(this::actionPerformed);

            Rapport_Clients = new JMenuItem("Rapport");
            Rapport_Clients.setMnemonic(KeyEvent.VK_R);
            Clients.add(Rapport_Clients);
            Rapport_Clients.addActionListener(this::actionPerformed);

            //Comptes>Fournisseurs
            Fournisseurs = new JMenu("Fournisseurs");
            Fournisseurs.setMnemonic('F');
            Comptes.add(Fournisseurs);

            Creer_Fournisseurs = new JMenuItem("Creer/Modifier");
            Creer_Fournisseurs.setMnemonic(KeyEvent.VK_C);
            Fournisseurs.add(Creer_Fournisseurs);
            Creer_Fournisseurs.addActionListener(this::actionPerformed);

            Rapport_Fournisseurs = new JMenuItem("Rapport");
            Rapport_Fournisseurs.setMnemonic(KeyEvent.VK_R);
            Fournisseurs.add(Rapport_Fournisseurs);
            Rapport_Fournisseurs.addActionListener(this::actionPerformed);

            //Comptes>Ville
            Ville = new JMenuItem("Ville");
            Ville.setMnemonic(KeyEvent.VK_V);
            Comptes.add(Ville);
            Ville.addActionListener(this::actionPerformed);

            //Stock
            Stock = new JMenu("Stock");
            Stock.setMnemonic(KeyEvent.VK_S);
            MenuBar.add(Stock);

            //Stock>Articles
            Articles = new JMenu("Articles");
            Articles.setMnemonic('A');
            Stock.add(Articles);

            Creer_Articles = new JMenuItem("Creer/Modifier");
            Creer_Articles.setMnemonic(KeyEvent.VK_C);
            Articles.add(Creer_Articles);
            Creer_Articles.addActionListener(this::actionPerformed);

            Rapport_Articles = new JMenuItem("Rapport");
            Rapport_Articles.setMnemonic(KeyEvent.VK_R);
            Articles.add(Rapport_Articles);
            Rapport_Articles.addActionListener(this::actionPerformed);

            //Stock>CategoriesArticles
            CategoriesArticles = new JMenuItem("Categories Articles");
            Stock.add(CategoriesArticles);
            CategoriesArticles.addActionListener(this::actionPerformed);

            //Outils
            Outils = new JMenu("Outils");
            Outils.setMnemonic(KeyEvent.VK_O);
            MenuBar.add(Outils);

            //Outils>Charger
            ChargerDuDisque = new JMenuItem("Charger du disque");
            ChargerDuDisque.setMnemonic(KeyEvent.VK_C);
            Outils.add(ChargerDuDisque);
            ChargerDuDisque.addActionListener(this::actionPerformed);

            //Outils>Sauvegarder
            SauvegarderSurDisque = new JMenuItem("Sauvegarder sur disque");
            SauvegarderSurDisque.setMnemonic(KeyEvent.VK_S);
            Outils.add(SauvegarderSurDisque);
            SauvegarderSurDisque.addActionListener(this::actionPerformed);

            //Quitter
            Quitter = new JMenu("Quitter");
            Quitter.setMnemonic(KeyEvent.VK_Q);
            MenuBar.add(Quitter);

            //Quitter>Version
            Version = new JMenuItem("Version");
            Version.setMnemonic(KeyEvent.VK_V);
            Quitter.add(Version);
            Version.addActionListener(this::actionPerformed);

            //Quitter>Quitter
            QuitterItem = new JMenuItem("Quitter");
            QuitterItem.setMnemonic(KeyEvent.VK_Q);
            Quitter.add(QuitterItem);
            QuitterItem.addActionListener(this::actionPerformed);
        }
        catch (Exception err){
            err.printStackTrace();
        }
    }
    public void actionPerformed(ActionEvent e) {
        String sActionButton = e.getActionCommand();

        if(sActionButton.equals(this.QuitterItem.getText())){
            this.MenuBar.dispatchEvent(new WindowEvent(this.MainMenu, WindowEvent.WINDOW_CLOSING));
            this.MainMenu.dispose();
            System.exit(0);
        }

        if(sActionButton.equals(this.Creer_Ventes.getText())){
            Ventes.Ventes_GUI panelVentes = new Ventes.Ventes_GUI();
            changePanel(panelVentes);
        }

        if(sActionButton.equals(this.Rapport_Ventes.getText())){
            changePanel(null);
        }
    }

    private void changePanel(IGenPanel newPanel){
        this.ContentPanel.setBorder(null);
        Component oldPanel = ((BorderLayout) this.ContentPanel.getLayout()).getLayoutComponent(BorderLayout.CENTER);
        if(oldPanel != null) this.ContentPanel.remove(oldPanel);

        Component compPanel = (Component) newPanel;
        if(compPanel != null) {
            this.ContentPanel.add(compPanel, BorderLayout.CENTER);
            this.borderContentPanel = BorderFactory.createTitledBorder(
                    BorderFactory.createEtchedBorder(EtchedBorder.RAISED, Color.GRAY, Color.WHITE),
                    newPanel.getPanelTitle(), TitledBorder.CENTER, TitledBorder.TOP,
                    BorderContentPanelTitleFont, Color.BLACK);
            this.ContentPanel.setBorder(this.borderContentPanel);
        }

        this.ContentPanel.repaint();
        this.ContentPanel.revalidate();

        return;
    }
}

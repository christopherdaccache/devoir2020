package Menu.Lib;

public interface IGenPanel {
    String panelTitle = "";
    public String getPanelTitle();
    public void setPanelTitle(String panelTitle);
}

package Menu.Lib;

import org.jetbrains.annotations.NotNull;

import java.awt.event.ActionEvent;

public interface IGenButtons {
    public Object Creer();
    public Boolean Enregistrer();
    public void Quitter();
    public void actionPerformed(@NotNull ActionEvent e);
}

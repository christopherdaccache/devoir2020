package Menu.Lib;

import java.awt.*;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class GenButtonsPanel extends JPanel {

    private JButton btnCreate, btnSave, btnQuit;
    private Font myFont;

    private final Rectangle panelBounds = new Rectangle(0, 0, 310, 30);
    public Rectangle getPanelBounds() { return panelBounds; }

    private IGenButtons myBtnController;
    public IGenButtons getMyBtnController() { return myBtnController; }
    public void setMyBtnController(IGenButtons myBtnController) { this.myBtnController = myBtnController; }

    public GenButtonsPanel(IGenButtons BtnController) {
        setBorder(null);
        setLayout(null);

        this.setMyBtnController(BtnController);

        myFont = new Font("Tahoma", Font.BOLD, 10);

        btnCreate = new JButton("Creer");
        btnCreate.setBounds(10, 0, 95, 28);
        btnCreate.setFont(myFont);
        btnCreate.addActionListener(this.getMyBtnController()::actionPerformed);
        add(btnCreate);

        btnSave = new JButton("Enregistrer");
        btnSave.setBounds(110, 0, 95, 28);
        btnSave.setFont(myFont);
        btnSave.addActionListener(this.getMyBtnController()::actionPerformed);
        add(btnSave);

        btnQuit = new JButton("Quitter");
        btnQuit.setBounds(210, 0, 95, 28);
        btnQuit.setFont(myFont);
        btnQuit.addActionListener(this.getMyBtnController()::actionPerformed);
        add(btnQuit);

        setBounds(getPanelBounds());
    }
}

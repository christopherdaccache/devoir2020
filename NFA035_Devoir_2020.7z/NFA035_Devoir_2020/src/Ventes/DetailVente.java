package Ventes;

public class DetailVente {
}

package Ventes;
import Transactions.*;

public class Vente extends TransactionClient{
    public Vente(){

    }
}

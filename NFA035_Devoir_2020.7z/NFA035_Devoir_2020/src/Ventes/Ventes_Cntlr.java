package Ventes;

import Menu.Lib.IGenButtons;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.lang.reflect.Method;

public class Ventes_Cntlr implements IGenButtons{

    public Object Creer(){
        JOptionPane.showMessageDialog(null, "in Ventes_Cntlr.Create");
        return new Object();
    }

    public Boolean Enregistrer(){
        JOptionPane.showMessageDialog(null, "in Ventes_Cntlr.Enregistrer");
        return true;
    }

    public void Quitter(){
        JOptionPane.showMessageDialog(null, "in Ventes_Cntlr.Quitter");
    }

    private void callGenBtns(String BtnMethodName){
        try{
            Method callMethod = this.getClass().getMethod(BtnMethodName);
            JOptionPane.showMessageDialog(null, callMethod.getName() + "\n" + callMethod.getReturnType());

        }
        catch (Exception err) {
            return;
        }
    }

    public void actionPerformed(@NotNull ActionEvent e) {
        String sActionButton = e.getActionCommand();

        sActionButton = "test";
        callGenBtns(sActionButton);

    }
}

package Ventes;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.ActionEvent;

import Menu.Lib.*;

/*
    width  = 660
    height = 555
*/

public class Ventes_GUI extends JPanel implements IGenPanel{
    private JTextField tfNoVente, tfDescription, tfDateVente, tfMontantVente;
    private JComboBox cbChoixClient;
    private JList listClient;
    private JTable tblDetailsVente;
    private JPanel pBtns;
    private Font myFont;
    private Ventes_Cntlr ControllerVentes;

    private String panelTitle;
    public String getPanelTitle() { return panelTitle; }
    public void setPanelTitle(String panelTitle) { this.panelTitle = panelTitle; }

	public Ventes_GUI() {
        initPanel();
    }

    public void initPanel(){
        setBorder(null);
        setLayout(null);

        this.setPanelTitle("Infos Ventes");
        ControllerVentes = new Ventes_Cntlr();

        pBtns = new GenButtonsPanel(ControllerVentes);
        add(pBtns);

        myFont = new Font("Tahoma", Font.BOLD, 10);

        cbChoixClient = new JComboBox();
        cbChoixClient.setBounds(449, 4, 194, 24);
        add(cbChoixClient);

        JLabel lblchoixClient = new JLabel("Choisir Client");
        lblchoixClient.setHorizontalAlignment(SwingConstants.RIGHT);
        lblchoixClient.setBounds(350, 4, 86, 24);
        lblchoixClient.setFont(myFont);
        add(lblchoixClient);

        tfNoVente = new JTextField();
        tfNoVente.setBounds(95, 38, 200, 25);
        add(tfNoVente);
        tfNoVente.setColumns(10);

        tfDescription = new JTextField();
        tfDescription.setColumns(10);
        tfDescription.setBounds(95, 73, 200, 25);
        add(tfDescription);

        tfDateVente = new JTextField();
        tfDateVente.setColumns(10);
        tfDateVente.setBounds(95, 109, 200, 25);
        add(tfDateVente);

        tfMontantVente = new JTextField();
        tfMontantVente.setColumns(10);
        tfMontantVente.setBounds(95, 147, 200, 25);
        add(tfMontantVente);

        JLabel lblNoVente = new JLabel("No Vente");
        lblNoVente.setHorizontalAlignment(SwingConstants.RIGHT);
        lblNoVente.setBounds(10, 44, 80, 13);
        lblNoVente.setFont(myFont);
        add(lblNoVente);

        JLabel lblDescription = new JLabel("Description");
        lblDescription.setHorizontalAlignment(SwingConstants.RIGHT);
        lblDescription.setBounds(10, 79, 80, 13);
        lblDescription.setFont(myFont);
        add(lblDescription);

        JLabel lblDateVente = new JLabel("Date Vente");
        lblDateVente.setHorizontalAlignment(SwingConstants.RIGHT);
        lblDateVente.setBounds(10, 115, 80, 13);
        lblDateVente.setFont(myFont);
        add(lblDateVente);

        JLabel lblMontantVente = new JLabel("Montant Vente");
        lblMontantVente.setHorizontalAlignment(SwingConstants.RIGHT);
        lblMontantVente.setBounds(10, 153, 80, 13);
        lblMontantVente.setFont(myFont);
        add(lblMontantVente);

        JScrollPane scrollListClient = new JScrollPane();
        scrollListClient.setBorder(null);
        scrollListClient.setBounds(322, 43, 321, 186);
        add(scrollListClient);

        listClient = new JList();
        scrollListClient.setViewportView(listClient);

        Font fontTitle = new Font("Tahoma", Font.BOLD, 12);
        Border listBorder = BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(EtchedBorder.RAISED, Color.GRAY, Color.WHITE),
                "Ventes", TitledBorder.CENTER, TitledBorder.TOP,
                fontTitle, Color.BLACK);

        listClient.setBorder(listBorder);

        JLabel lblDetailsVente = new JLabel("D\u00E9tails Vente");
        lblDetailsVente.setBounds(10, 219, 85, 13);
        lblDetailsVente.setFont(myFont);
        add(lblDetailsVente);

        JScrollPane scrollDetailVente = new JScrollPane();
        scrollDetailVente.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollDetailVente.setBounds(10, 242, 633, 301);
        add(scrollDetailVente);

        tblDetailsVente = new JTable();
        scrollDetailVente.setViewportView(tblDetailsVente);
    }

    public void actionPerformed(ActionEvent e) {
        String sActionButton = e.getActionCommand();

        JOptionPane.showMessageDialog(this, sActionButton);
    }
}

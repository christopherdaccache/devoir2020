package Achats;

public class DetailAchat {
}

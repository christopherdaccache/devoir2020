package Achats;
import Transactions.*;

public class Achat extends TransactionFournisseur{
}
